#!/usr/bin/env bash
cd /home/user

exec ./chall