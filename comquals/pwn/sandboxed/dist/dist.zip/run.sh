#!/bin/sh

./sandbox ./chall
